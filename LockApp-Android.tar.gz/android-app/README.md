# LockApp — Android Lock Screen App

Aplikasi layar kunci dengan teks TERKUNCI berkedip merah, getaran, senter, dan suara alarm.
PIN untuk membuka: **2026**

---

## Struktur Project

```
android-app/
├── build.sh                          ← Script build otomatis (jalankan ini!)
├── build.gradle                      ← Project-level Gradle config
├── settings.gradle                   ← Project settings
├── gradlew                           ← Gradle wrapper script
├── gradle/wrapper/
│   └── gradle-wrapper.properties
└── app/
    ├── build.gradle                  ← App-level Gradle config
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml       ← Permissions & activity config
        ├── java/com/example/lockapp/
        │   └── MainActivity.java     ← Logika utama aplikasi
        └── res/
            ├── layout/
            │   └── activity_main.xml ← Layout layar kunci
            └── values/
                └── strings.xml
```

---

## Cara Build

### Opsi 1 — Otomatis via build.sh (Linux/Replit)

```bash
cd android-app
chmod +x build.sh
./build.sh
```

Script ini akan:
1. Cek & install Java (jika belum ada)
2. Download Android Command Line Tools (~130MB, sekali saja)
3. Install platform SDK android-34 & build-tools 34.0.0
4. Build APK debug otomatis

**APK output:** `app/build/outputs/apk/debug/app-debug.apk`

---

### Opsi 2 — Android Studio (Windows/Mac/Linux)

1. Buka Android Studio → **Open** → pilih folder `android-app/`
2. Tunggu Gradle sync selesai
3. Buat file `local.properties` (salin dari `local.properties.template`) dan isi path SDK Anda
4. Klik **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK ada di: `app/build/outputs/apk/debug/app-debug.apk`

---

### Opsi 3 — Command Line (dengan Android SDK sudah terinstall)

```bash
cd android-app

# Buat local.properties
echo "sdk.dir=$ANDROID_HOME" > local.properties

# Build
chmod +x gradlew
./gradlew assembleDebug

# APK output
ls app/build/outputs/apk/debug/
```

---

### Install ke HP via ADB

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

Atau salin file APK ke HP → buka lewat File Manager → Install.

> **Catatan:** Aktifkan "Install dari sumber tidak dikenal" di pengaturan HP.

---

## Fitur Aplikasi

| Fitur | Detail |
|---|---|
| Layar | Hitam penuh, immersive mode |
| Teks | "TERKUNCI" merah berkedip (0.5 detik interval) |
| Getaran | Terus-menerus (pola 400ms on / 100ms off) |
| Senter | Nyala-mati otomatis (0.8 detik interval) |
| Suara | Alarm 800Hz tiap 2 detik via ToneGenerator |
| Volume | Otomatis max saat app buka |
| Tombol Back | Butuh tekan 3x untuk tampilkan input PIN |
| Tombol Home | Diblokir (app sudah set sebagai HOME) |
| PIN Unlock | Ketik `2026` → tekan BUKA |

---

## Cara Tampilkan Input PIN

- **Tahan (long press)** di layar hitam → input PIN muncul
- **Tekan tombol Back 3x berturut-turut** → input PIN muncul
- Ketik PIN: `2026` → tekan **BUKA**

---

## Permissions yang Dibutuhkan

- `VIBRATE` — untuk getaran
- `CAMERA` + `FLASHLIGHT` — untuk senter
- `MODIFY_AUDIO_SETTINGS` — untuk max volume
- `DISABLE_KEYGUARD` — untuk tampil di atas lock screen

---

## Requirements

- Android 5.0+ (API 21+)
- HP dengan flash/senter untuk fitur senter
- Java 17+ untuk build
