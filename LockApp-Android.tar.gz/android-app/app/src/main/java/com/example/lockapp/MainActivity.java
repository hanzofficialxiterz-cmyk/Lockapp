package com.example.lockapp;

import android.app.Activity;
import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String CORRECT_PIN = "2026";
    private static final int MAX_BACK_PRESSES = 3;

    private TextView tvLocked;
    private LinearLayout pinLayout;
    private EditText etPin;
    private Button btnUnlock;
    private TextView tvHint;

    private Vibrator vibrator;
    private ToneGenerator toneGenerator;
    private CameraManager cameraManager;
    private String cameraId;
    private AudioManager audioManager;
    private Handler handler;

    private boolean isFlashOn = false;
    private boolean isRunning = false;
    private int backPressCount = 0;
    private long lastBackPressTime = 0;

    // Runnables
    private Runnable flashRunnable;
    private Runnable toneRunnable;
    private Runnable vibrateRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on, show over lock screen, full screen
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        setContentView(R.layout.activity_main);

        // Hide navigation and status bar (immersive sticky)
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        tvLocked   = findViewById(R.id.tvLocked);
        pinLayout  = findViewById(R.id.pinLayout);
        etPin      = findViewById(R.id.etPin);
        btnUnlock  = findViewById(R.id.btnUnlock);
        tvHint     = findViewById(R.id.tvHint);

        handler = new Handler(Looper.getMainLooper());

        // Init services
        vibrator    = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        try {
            toneGenerator = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
        } catch (Exception e) {
            toneGenerator = null;
        }

        // Get rear camera ID
        try {
            for (String id : cameraManager.getCameraIdList()) {
                cameraId = id;
                break;
            }
        } catch (CameraAccessException e) {
            cameraId = null;
        }

        // Max volume
        setMaxVolume();

        // Start blinking animation on TERKUNCI
        startBlinking();

        // Unlock button
        btnUnlock.setOnClickListener(v -> checkPin());

        // Long press on screen to show PIN input
        tvLocked.setOnLongClickListener(v -> {
            showPinInput();
            return true;
        });
        findViewById(R.id.rootLayout).setOnLongClickListener(v -> {
            showPinInput();
            return true;
        });

        // Start all effects
        isRunning = true;
        startVibration();
        startFlash();
        startTone();
    }

    // ─── Volume ────────────────────────────────────────────────────────────────

    private void setMaxVolume() {
        if (audioManager == null) return;
        int maxAlarm  = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM);
        int maxRing   = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING);
        int maxMusic  = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        audioManager.setStreamVolume(AudioManager.STREAM_ALARM,  maxAlarm,  0);
        audioManager.setStreamVolume(AudioManager.STREAM_RING,   maxRing,   0);
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,  maxMusic,  0);
        // Try to disable silent/vibrate mode
        try {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        } catch (Exception ignored) {}
    }

    // ─── Blink ─────────────────────────────────────────────────────────────────

    private void startBlinking() {
        AlphaAnimation blink = new AlphaAnimation(1.0f, 0.0f);
        blink.setDuration(500);
        blink.setRepeatMode(Animation.REVERSE);
        blink.setRepeatCount(Animation.INFINITE);
        tvLocked.startAnimation(blink);
    }

    // ─── Vibration ─────────────────────────────────────────────────────────────

    private void startVibration() {
        if (vibrator == null || !vibrator.hasVibrator()) return;

        vibrateRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        VibrationEffect effect = VibrationEffect.createWaveform(
                            new long[]{0, 400, 100, 400},
                            new int[]{0, 255, 0, 200},
                            0
                        );
                        vibrator.vibrate(effect);
                    } else {
                        vibrator.vibrate(new long[]{0, 400, 100, 400}, 0);
                    }
                } catch (Exception ignored) {}
                // Re-trigger every 2 seconds to keep it alive
                handler.postDelayed(this, 2000);
            }
        };
        handler.post(vibrateRunnable);
    }

    // ─── Flashlight ────────────────────────────────────────────────────────────

    private void startFlash() {
        if (cameraId == null) return;

        flashRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                try {
                    isFlashOn = !isFlashOn;
                    cameraManager.setTorchMode(cameraId, isFlashOn);
                } catch (CameraAccessException ignored) {}
                handler.postDelayed(this, 800);
            }
        };
        handler.post(flashRunnable);
    }

    // ─── Tone (800 Hz) ─────────────────────────────────────────────────────────

    private void startTone() {
        toneRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                try {
                    if (toneGenerator != null) {
                        toneGenerator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400);
                    }
                } catch (Exception ignored) {}
                handler.postDelayed(this, 2000);
            }
        };
        handler.post(toneRunnable);
    }

    // ─── PIN ───────────────────────────────────────────────────────────────────

    private void showPinInput() {
        pinLayout.setVisibility(View.VISIBLE);
        tvHint.setVisibility(View.VISIBLE);
        tvHint.setText("Tahan layar untuk tampilkan PIN");
        etPin.requestFocus();
    }

    private void checkPin() {
        String entered = etPin.getText().toString().trim();
        if (CORRECT_PIN.equals(entered)) {
            stopAll();
            Toast.makeText(this, "Terbuka!", Toast.LENGTH_SHORT).show();
            // Close the app
            finishAffinity();
            System.exit(0);
        } else {
            etPin.setText("");
            etPin.setError("PIN salah");
            // Extra vibration on wrong PIN
            if (vibrator != null) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(300);
                }
            }
        }
    }

    // ─── Key intercept (susah restart) ─────────────────────────────────────────

    @Override
    public void onBackPressed() {
        long now = System.currentTimeMillis();
        if (now - lastBackPressTime < 1000) {
            backPressCount++;
        } else {
            backPressCount = 1;
        }
        lastBackPressTime = now;

        if (backPressCount >= MAX_BACK_PRESSES) {
            showPinInput();
            backPressCount = 0;
        } else {
            Toast.makeText(this,
                "Tekan " + (MAX_BACK_PRESSES - backPressCount) + "x lagi untuk tampilkan PIN",
                Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Block volume-down-as-back, home, recents, power behavior
        switch (keyCode) {
            case KeyEvent.KEYCODE_HOME:
            case KeyEvent.KEYCODE_APP_SWITCH:
            case KeyEvent.KEYCODE_MENU:
                return true; // consumed, do nothing
            case KeyEvent.KEYCODE_VOLUME_UP:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                // Keep volume at max
                setMaxVolume();
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    // ─── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onPause() {
        super.onPause();
        // Bring back to front if user tries to leave
        handler.postDelayed(() -> {
            if (isRunning) {
                // Re-apply immersive mode
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                );
            }
        }, 200);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setMaxVolume();
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    @Override
    protected void onDestroy() {
        stopAll();
        super.onDestroy();
    }

    // ─── Stop all ──────────────────────────────────────────────────────────────

    private void stopAll() {
        isRunning = false;

        if (flashRunnable != null)   handler.removeCallbacks(flashRunnable);
        if (toneRunnable != null)    handler.removeCallbacks(toneRunnable);
        if (vibrateRunnable != null) handler.removeCallbacks(vibrateRunnable);

        if (vibrator != null) vibrator.cancel();

        if (toneGenerator != null) {
            toneGenerator.stopTone();
            toneGenerator.release();
            toneGenerator = null;
        }

        // Turn off flash
        if (cameraId != null) {
            try {
                cameraManager.setTorchMode(cameraId, false);
            } catch (CameraAccessException ignored) {}
        }
    }
}
