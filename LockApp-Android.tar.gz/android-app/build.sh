#!/bin/bash
set -e

# ─────────────────────────────────────────────────────────────────────────────
# build.sh — Auto-install Android SDK & Build APK (Debug)
# Jalankan di Replit atau Linux environment manapun
# Output: app/build/outputs/apk/debug/app-debug.apk
# ─────────────────────────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ── Konfigurasi ───────────────────────────────────────────────────────────────
ANDROID_SDK_VERSION="commandlinetools-linux-10406996_latest.zip"
ANDROID_SDK_URL="https://dl.google.com/android/repository/${ANDROID_SDK_VERSION}"
ANDROID_HOME="${SCRIPT_DIR}/.android-sdk"
BUILD_TOOLS_VERSION="34.0.0"
PLATFORM_VERSION="android-34"

export ANDROID_HOME
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/$BUILD_TOOLS_VERSION:$PATH"

echo "═══════════════════════════════════════════════════"
echo "  LockApp Android Build Script"
echo "═══════════════════════════════════════════════════"

# ── 1. Cek Java ───────────────────────────────────────────────────────────────
echo ""
echo "[1/5] Memeriksa Java..."
if ! command -v java &>/dev/null; then
    echo "Java tidak ditemukan. Menginstall OpenJDK 17..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get update -q && sudo apt-get install -y -q openjdk-17-jdk
    elif command -v nix-env &>/dev/null; then
        nix-env -iA nixpkgs.jdk17
    else
        echo "ERROR: Tidak bisa install Java. Install manual: sudo apt install openjdk-17-jdk"
        exit 1
    fi
fi
java -version
export JAVA_HOME="$(java -XshowSettings:all -version 2>&1 | grep 'java.home' | awk '{print $3}')"

# ── 2. Download & Setup Android SDK ───────────────────────────────────────────
echo ""
echo "[2/5] Menyiapkan Android SDK..."

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo "  Mendownload Android Command Line Tools (~130MB)..."
    mkdir -p "$ANDROID_HOME/cmdline-tools"
    
    TMP_ZIP="/tmp/${ANDROID_SDK_VERSION}"
    if [ ! -f "$TMP_ZIP" ]; then
        curl -L --progress-bar -o "$TMP_ZIP" "$ANDROID_SDK_URL"
    fi
    
    echo "  Mengekstrak..."
    unzip -q "$TMP_ZIP" -d "$ANDROID_HOME/cmdline-tools/"
    mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
    rm -f "$TMP_ZIP"
    echo "  Android Command Line Tools siap."
else
    echo "  Android Command Line Tools sudah ada, skip download."
fi

# ── 3. Accept Licenses & Install Components ────────────────────────────────────
echo ""
echo "[3/5] Menginstall SDK components (platform + build-tools)..."

yes | sdkmanager --licenses > /dev/null 2>&1 || true

if [ ! -d "$ANDROID_HOME/platforms/$PLATFORM_VERSION" ]; then
    echo "  Menginstall platform $PLATFORM_VERSION..."
    sdkmanager "platforms;$PLATFORM_VERSION"
else
    echo "  Platform $PLATFORM_VERSION sudah ada."
fi

if [ ! -d "$ANDROID_HOME/build-tools/$BUILD_TOOLS_VERSION" ]; then
    echo "  Menginstall build-tools $BUILD_TOOLS_VERSION..."
    sdkmanager "build-tools;$BUILD_TOOLS_VERSION"
else
    echo "  build-tools $BUILD_TOOLS_VERSION sudah ada."
fi

# ── 4. Setup Gradle Wrapper ────────────────────────────────────────────────────
echo ""
echo "[4/5] Menyiapkan Gradle Wrapper..."

if [ ! -f "$SCRIPT_DIR/gradlew" ]; then
    echo "  Mendownload Gradle Wrapper..."
    GRADLE_VERSION="8.0"
    GRADLE_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
    TMP_GRADLE="/tmp/gradle-${GRADLE_VERSION}-bin.zip"
    
    if [ ! -f "$TMP_GRADLE" ]; then
        curl -L --progress-bar -o "$TMP_GRADLE" "$GRADLE_URL"
    fi
    
    TMP_GRADLE_DIR="/tmp/gradle-${GRADLE_VERSION}"
    unzip -q "$TMP_GRADLE" -d /tmp/
    
    # Copy gradlew script
    cp "${TMP_GRADLE_DIR}/bin/gradle" "$SCRIPT_DIR/gradlew"
    chmod +x "$SCRIPT_DIR/gradlew"
    
    # Update wrapper properties to use local gradle
    mkdir -p "$SCRIPT_DIR/gradle/wrapper"
    cat > "$SCRIPT_DIR/gradle/wrapper/gradle-wrapper.properties" <<EOF
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
EOF
    echo "  Gradle Wrapper siap."
else
    chmod +x "$SCRIPT_DIR/gradlew"
    echo "  gradlew sudah ada."
fi

# ── 5. Build APK ──────────────────────────────────────────────────────────────
echo ""
echo "[5/5] Build APK Debug..."
echo ""

# Bersihkan build sebelumnya
"$SCRIPT_DIR/gradlew" clean 2>&1 | tail -3

# Build APK
"$SCRIPT_DIR/gradlew" assembleDebug --stacktrace 2>&1

# ── Hasil ─────────────────────────────────────────────────────────────────────
APK_PATH="$SCRIPT_DIR/app/build/outputs/apk/debug/app-debug.apk"

echo ""
echo "═══════════════════════════════════════════════════"
if [ -f "$APK_PATH" ]; then
    APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo "  ✓ BUILD SUKSES!"
    echo ""
    echo "  APK Location : $APK_PATH"
    echo "  APK Size     : $APK_SIZE"
    echo ""
    echo "  Cara install ke HP:"
    echo "    adb install \"$APK_PATH\""
    echo "  atau salin file APK ke HP lalu install manual."
else
    echo "  ✗ BUILD GAGAL. Lihat error di atas."
    exit 1
fi
echo "═══════════════════════════════════════════════════"
